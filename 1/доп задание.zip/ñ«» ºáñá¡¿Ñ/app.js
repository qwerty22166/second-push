let num = prompt("Задайте певое число");

let data = prompt("Задайте второе число");

if(num > data) {
console.log(num + ">" + data);
} else if(num < data) {
    console.log(num + "<" + data)
} else {
    console.log(num + "=" + data)
}